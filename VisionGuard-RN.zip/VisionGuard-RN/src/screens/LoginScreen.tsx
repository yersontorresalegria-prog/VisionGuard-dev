import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, SafeAreaView, KeyboardAvoidingView, Platform, Alert } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';

const COLORS = {
  background: '#111827', card: '#1F2937', border: '#4B5563',
  cyan: '#00D4FF', text: '#FFFFFF', textSecondary: '#9CA3AF',
  secondary: '#3B82F6',
};

export function LoginScreen({ onLogin }: { onLogin: () => void }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPass, setShowPass] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleLogin = () => {
    if (!email || !password) {
      Alert.alert('Error', 'Por favor ingresa tu correo y contraseña.');
      return;
    }
    setLoading(true);
    setTimeout(() => { setLoading(false); onLogin(); }, 1000);
  };

  return (
    <SafeAreaView style={styles.container}>
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={styles.inner}>
        <View style={styles.header}>
          <View style={styles.logoCircle}>
            <MaterialCommunityIcons name="shield-eye" size={52} color={COLORS.cyan} />
          </View>
          <Text style={styles.title}>VisionGuard</Text>
          <Text style={styles.subtitle}>Navegación IA para personas con discapacidad visual</Text>
        </View>

        <View style={styles.form}>
          <View style={styles.inputRow}>
            <MaterialCommunityIcons name="email-outline" size={20} color={COLORS.textSecondary} style={styles.inputIcon} />
            <TextInput style={styles.input} placeholder="Correo electrónico" placeholderTextColor={COLORS.textSecondary}
              value={email} onChangeText={setEmail} keyboardType="email-address" autoCapitalize="none" />
          </View>

          <View style={styles.inputRow}>
            <MaterialCommunityIcons name="lock-outline" size={20} color={COLORS.textSecondary} style={styles.inputIcon} />
            <TextInput style={styles.input} placeholder="Contraseña" placeholderTextColor={COLORS.textSecondary}
              value={password} onChangeText={setPassword} secureTextEntry={!showPass} />
            <TouchableOpacity onPress={() => setShowPass(!showPass)}>
              <MaterialCommunityIcons name={showPass ? 'eye-off' : 'eye'} size={20} color={COLORS.textSecondary} />
            </TouchableOpacity>
          </View>

          <TouchableOpacity style={[styles.btnPrimary, loading && { opacity: 0.7 }]} onPress={handleLogin} disabled={loading}>
            <Text style={styles.btnPrimaryText}>{loading ? 'Ingresando...' : 'Iniciar Sesión'}</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.btnSecondary} onPress={() => Alert.alert('Registro', 'Funcionalidad próximamente.')}>
            <Text style={styles.btnSecondaryText}>¿No tienes cuenta? Regístrate gratis</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.sosContainer}>
          <TouchableOpacity style={styles.sosBtn} onPress={() => Alert.alert('SOS', 'Llamando a contacto de emergencia...')}>
            <MaterialCommunityIcons name="phone-alert" size={20} color="#FFF" />
            <Text style={styles.sosText}>BOTÓN SOS EMERGENCIA</Text>
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.background },
  inner: { flex: 1, justifyContent: 'center', paddingHorizontal: 24 },
  header: { alignItems: 'center', marginBottom: 40 },
  logoCircle: { width: 96, height: 96, borderRadius: 48, backgroundColor: COLORS.card, borderWidth: 2, borderColor: COLORS.cyan, justifyContent: 'center', alignItems: 'center', marginBottom: 16 },
  title: { fontSize: 34, fontWeight: '800', color: COLORS.text, letterSpacing: 1 },
  subtitle: { fontSize: 13, color: COLORS.textSecondary, marginTop: 6, textAlign: 'center', paddingHorizontal: 20 },
  form: { gap: 14 },
  inputRow: { flexDirection: 'row', alignItems: 'center', backgroundColor: COLORS.card, borderRadius: 12, borderWidth: 1, borderColor: COLORS.border, paddingHorizontal: 16, height: 56 },
  inputIcon: { marginRight: 12 },
  input: { flex: 1, color: COLORS.text, fontSize: 16 },
  btnPrimary: { backgroundColor: COLORS.cyan, borderRadius: 12, height: 56, justifyContent: 'center', alignItems: 'center', marginTop: 8 },
  btnPrimaryText: { color: '#000', fontSize: 16, fontWeight: '700' },
  btnSecondary: { alignItems: 'center', paddingVertical: 12 },
  btnSecondaryText: { color: COLORS.secondary, fontSize: 14 },
  sosContainer: { marginTop: 32 },
  sosBtn: { backgroundColor: '#DC2626', borderRadius: 12, height: 52, flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 10 },
  sosText: { color: '#FFF', fontWeight: '700', fontSize: 14, letterSpacing: 1 },
});
